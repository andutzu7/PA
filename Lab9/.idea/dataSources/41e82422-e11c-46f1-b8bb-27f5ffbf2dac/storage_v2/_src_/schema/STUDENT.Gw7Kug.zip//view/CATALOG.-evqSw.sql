create view CATALOG as
SELECT nume, prenume, valoare as nota, TITLU_CURS, ID_CURS, id_student
FROM (SELECT *
      FROM STUDENTI s
               JOIN note n on s.ID = n.ID_STUDENT
               JOIN cursuri c on c.ID = n.ID_CURS)
/

create trigger INSERT_CHECK
    instead of insert
    on CATALOG
    for each row
begin
    -- missing source code
end
/

create trigger UPDATE_ENTRY
    instead of update
    on CATALOG
    for each row
begin
    -- missing source code
end
/

create trigger DELETE_ENTRY
    instead of delete
    on CATALOG
    for each row
begin
    -- missing source code
end
/

