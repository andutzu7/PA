create FUNCTION insert_grade2(pi_id_student IN studenti.id%type)
  RETURN VARCHAR2
AS
  mesaj        VARCHAR2(32767);
  counter      INTEGER;
BEGIN
SELECT COUNT(*) INTO counter FROM NOTE WHERE ID_STUDENT = pi_id_student ;
insert into note (id, id_student, id_curs, valoare) values(69420,pi_id_student, 1, 10);
  mesaj := 'Studentului cu id ul' || pi_id_student || 'i-a fost pusa nota 10';
    return mesaj;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
     return ('Studentul cu ID-ul ' || pi_id_student || ' are deja nota la materia selectata u e gucci');

END insert_grade2;
/

