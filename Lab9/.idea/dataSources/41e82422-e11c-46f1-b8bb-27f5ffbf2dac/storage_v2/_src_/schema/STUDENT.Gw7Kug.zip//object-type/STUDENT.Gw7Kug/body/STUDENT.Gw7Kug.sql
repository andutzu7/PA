create TYPE BODY student AS
   MEMBER PROCEDURE afiseaza_foaie_matricola IS
   BEGIN
       DBMS_OUTPUT.PUT_LINE('Aceasta procedura calculeaza si afiseaza foaia matricola');
   END afiseaza_foaie_matricola;

    CONSTRUCTOR FUNCTION student(nume varchar2, prenume varchar2)
    RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.nume := nume;
    SELF.prenume := prenume;
    SELF.data_nastere := sysdate;
    SELF.an := 1;
    SELF.grupa := 'A1';
    RETURN;
  END;
END;
/

