create FUNCTION get_average(in_nume IN varchar2,in_prenume IN varchar2)
  RETURN NUMBER
AS

  nota_recenta INTEGER;
  media NUMBER;
  counter INTEGER;
  student_inexistent EXCEPTION;
  PRAGMA EXCEPTION_INIT(student_inexistent, -20001);

BEGIN
select AVG(VALOARE) into media from (select * FROM STUDENTI s JOIN NOTE n on s.ID=n.ID_STUDENT) where NUME LIKE in_nume and PRENUME LIKE in_prenume AND VALOARE IS NOT NULL;
    IF media>0  THEN
        return media;
    ELSE
        RAISE student_inexistent;
    end if;
EXCEPTION
WHEN student_inexistent THEN
 SELECT COUNT(*) INTO counter FROM studenti where NUME LIKE in_nume and PRENUME LIKE in_prenume ;
  IF counter = 0 THEN
    return -1;
ELSE
      raise_application_error(-20123,'UNKNOWN ERROR');
    END IF;
END get_average;
/

