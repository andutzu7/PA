create trigger INSERT_CHECK
    instead of insert
    on CATALOG
    for each row
declare
    aux          number;
    c_studenti   number;
    c_materie    number;
    newstudentID number;
    d            date;
    email        varchar2(40);
    aux2         number;

BEGIN

    SELECT TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') "NOW" into d FROM DUAL;
    select count(nume) into c_studenti from studenti where nume like :new.nume and prenume like :new.prenume;
    if c_studenti < 0 THEN --studentul nu exista
        SELECT ROUND(DBMS_RANDOM.VALUE(1000, 5000)) into newstudentID FROM dual;
        email := 'mail@mail.com';
        insert into STUDENTI
        values (newstudentID, DBMS_RANDOM.string('x', 6), :new.nume, :new.prenume, 1, 'A4', 810.00, d, email, d, d);
    end if;
    SELECT count(TITLU_CURS) --verificam daca materia exista
    into c_materie
    FROM (SELECT *
          FROM STUDENTI s
                   JOIN note n on s.ID = n.ID_STUDENT
                   JOIN cursuri c on c.ID = n.ID_CURS
         )
    WHERE TITLU_CURS like :new.TITLU_CURS;

    if (c_materie <= 0) then --cursul nu exista

        SELECT ROUND(DBMS_RANDOM.VALUE(1000, 5000)) into aux FROM dual;
        insert into cursuri values (aux, :new.TITLU_CURS, 4, 1, 6, d, d);
        insert into note values (aux, :new.id_curs, aux, :new.nota, d, d, d);
        insert into didactic values(aux,aux,aux,d,d);
    else --cursul exista

        SELECT id_curs
        into aux2
        FROM (SELECT *
              FROM STUDENTI s
                       JOIN note n on s.ID = n.ID_STUDENT
                       JOIN cursuri c on c.ID = n.ID_CURS
             )
        WHERE TITLU_CURS like :new.TITLU_CURS;
        SELECT ROUND(DBMS_RANDOM.VALUE(1000, 5000)) into aux FROM dual;
        insert into note values (aux, :new.id_curs, aux2, :new.nota, d, d, d);

    end if;
end;
/

