create TYPE BODY car AS
   MEMBER PROCEDURE  setYear(an number) IS
   BEGIN
        self.year :=an;
    END setYear;
    member function getName RETURN varchar2 IS
    BEGIN
        return self.name;
    END getName;
    member function getModel RETURN varchar2 IS
    BEGIN
        return self.model;
    END getModel;
    member function getYear RETURN number IS
    BEGIN
        return self.year;
    END getYear;
    CONSTRUCTOR FUNCTION car(nume varchar2, model varchar2)
    RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.name := nume;
    SELF.model := model;
    SELF.year := 1985;
    RETURN;
  END;
    MAP member FUNCTION COMPAREBYYEAR RETURN NUMBER AS
    BEGIN
    RETURN self.year;
    END;

END;
/

