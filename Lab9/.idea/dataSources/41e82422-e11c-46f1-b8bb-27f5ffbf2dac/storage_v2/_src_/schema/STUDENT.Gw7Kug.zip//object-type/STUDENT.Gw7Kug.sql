create TYPE student FORCE AS OBJECT
(nume varchar2(10),
 prenume varchar2(10),
 grupa varchar2(4),
 an number(1),
 data_nastere date,
 member procedure afiseaza_foaie_matricola,
 CONSTRUCTOR FUNCTION student(nume varchar2, prenume varchar2)
    RETURN SELF AS RESULT
)
/

