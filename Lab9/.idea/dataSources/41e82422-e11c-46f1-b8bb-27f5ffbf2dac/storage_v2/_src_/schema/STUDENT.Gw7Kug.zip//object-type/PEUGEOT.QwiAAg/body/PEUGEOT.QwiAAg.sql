create TYPE BODY Peugeot AS
    member function getSeries RETURN varchar2 IS
    BEGIN
        return self.chassySeries;
    END getSeries;
    overriding member function getName return varchar2
    IS
    BEGIN
        RETURN 'Masina se numeste ' || self.NAME;
    END getName;
    CONSTRUCTOR FUNCTION Peugeot(model varchar2,an number,serie varchar2)
    RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.name := 'Peugeot';
    SELF.model := model;
    SELF.year := an;
    self.CHASSYSERIES :=serie;
    RETURN;
  END;
END;
/

