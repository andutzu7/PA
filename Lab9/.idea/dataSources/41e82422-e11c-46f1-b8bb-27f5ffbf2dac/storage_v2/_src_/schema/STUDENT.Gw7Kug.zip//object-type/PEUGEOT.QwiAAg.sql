create TYPE Peugeot UNDER car(
    chassySeries varchar2(30),
    MEMBER FUNCTION getSeries return varchar2,
    overriding member function getName return varchar2,
    CONSTRUCTOR FUNCTION Peugeot(model varchar2,an number,serie varchar2)
    RETURN SELF AS RESULT

)
/

