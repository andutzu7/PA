create trigger DML_STUD2
    after insert or update or delete
    on STUDENTI
declare   
   v_nume studenti.nume%type;
BEGIN  
  select nume into v_nume from studenti where id=200;
  dbms_output.put_line('After DML TRIGGER: ' || v_nume);
END;
/

