create trigger DELETE_ENTRY
    instead of delete
    on CATALOG
    for each row
begin
    delete
    from STUDENTI
    where nume like :old.nume
      and prenume like :old.prenume;

    delete
    from note
    where id_student = :old.id_student;
end;
/

