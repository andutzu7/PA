create FUNCTION insert_grade(pi_id_student IN studenti.id%type)
  RETURN VARCHAR2
AS
  mesaj        VARCHAR2(32767);
  counter      INTEGER;
  nota_deja_existenta EXCEPTION;
  PRAGMA EXCEPTION_INIT(nota_deja_existenta, -20001);

BEGIN
SELECT COUNT(*) INTO counter FROM NOTE WHERE ID_STUDENT = pi_id_student ;
    IF counter=0  THEN
      UPDATE NOTE SET VALOARE = 10 WHERE id_student = pi_id_student AND ID_CURS=1;
    ELSE
        RAISE nota_deja_existenta;
      end if;
  mesaj := 'Studentului cu id ul' || pi_id_student || 'i-a fost pusa nota 10';
    return mesaj;
EXCEPTION
    WHEN nota_deja_existenta THEN
     return ('Studentul cu ID-ul ' || pi_id_student || ' are deja nota la materia selectata');

END insert_grade;
/

