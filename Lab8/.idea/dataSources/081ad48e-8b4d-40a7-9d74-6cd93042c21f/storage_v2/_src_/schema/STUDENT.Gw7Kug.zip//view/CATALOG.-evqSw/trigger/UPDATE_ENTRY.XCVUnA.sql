create trigger UPDATE_ENTRY
    instead of update
    on CATALOG
    for each row
declare
    n number;
begin
    IF :new.nota > :old.nota then
        n := :new.nota;
    else
        n := :old.nota;
    end if;
    Update (
        SELECT *
        FROM STUDENTI s
                 JOIN note n on s.ID = n.ID_STUDENT
                 JOIN cursuri c on c.ID = n.ID_CURS
    )
    SET VALOARE=n
    where nume like :old.nume
      and prenume like :old.prenume
      and TITLU_CURS like :old.titlu_curs;

    update NOTE
    set UPDATED_AT= (SELECT TO_DATE(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') "NOW"
                     FROM DUAL)
    where ID_STUDENT = :old.ID_STUDENT
      AND ID_CURS = :old.ID_CURS;

end;
/

