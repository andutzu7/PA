create TYPE car FORCE AS OBJECT
(name varchar2(10),
 model varchar2(10),
 year number,
  member function getName RETURN varchar2,
  member function getModel RETURN varchar2,
  member function getYear RETURN number,
  member procedure setYear (an number),
 CONSTRUCTOR FUNCTION car(nume varchar2, model varchar2)
    RETURN SELF AS RESULT,
 MAP member FUNCTION COMPAREBYYEAR RETURN NUMBER
)NOT FINAL
/

